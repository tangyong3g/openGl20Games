/** Automatically generated file. DO NOT MODIFY */
package com.bn.Sample9_4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}